(function () {
	'use strict';
		angular.module(FAM_CONTROLLER)
		.controller('menuCtrl', menuCtrl);
		menuCtrl.$inject = ['$scope', '$stateParams', '$http', '$timeout'];  
		function menuCtrl($scope, $stateParams, $http, $timeout) {
			
		}
})();
 